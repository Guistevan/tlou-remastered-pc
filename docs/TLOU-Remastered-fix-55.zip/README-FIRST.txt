TLOU Remastered PC - volumetric lighting fix for issue #55
Pull request: https://github.com/ravencaio/tlou-remastered-pc/pull/230
Tested source change: a00ea048c90a56ef279ed630d62a2482f4e9f1bf
Patch base: 875161879f46db5f8cd265b46d10a27d3a63f68c

For the maintainer
From a clean checkout of the base above, extract this ZIP outside the checkout.
Run git apply --check /path/to/issue-55.patch, then git am /path/to/issue-55.patch.
The patch includes the code and four visual comparisons. The tools/ and docs/
directories also contain the changed files for inspection.
Merging PR #230 integrates the same source change. Choose one method.

Building a cache for a compatible installation
Follow tools/volumetrics/README.md. The builder needs an original populated
cache and the specified compiler tools. Keep the original cache for rollback.
The reporter tested the RTX 5060 on Windows with CUSA00552 version 01.11.

Para guardar a sua copia
O jogo no seu PC ja usa a correcao. Guarde este ZIP como backup do codigo.
Para gerar o cache em outra instalacao compativel, siga tools/volumetrics/README.md.
As quatro comparacoes de antes e depois ficam em docs/images/issue-55/.
