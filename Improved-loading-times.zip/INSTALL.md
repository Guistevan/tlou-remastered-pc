# Improved loading times

This source patch targets The Last of Us Remastered **CUSA00552, update 1.11**. It was prepared against upstream commit `5a9cdbb`. It contains a Python source diff, this guide, and the project license.

## Measured result

| Save | Before | After | Reduction |
| --- | ---: | ---: | ---: |
| Bill's Town – Graveyard | 70.139 s | 12.364 s | 57.775 s (82.4%) |

The comparison used the same checkpoint on the same PC. The interval starts at the first archive I/O event after confirming Continue and ends at the last archive I/O event before the runtime creates the `Load vTex` thread. The resulting scene, character input, and clean exit were checked in-game. The scoped implementation also loaded the Hydroelectric Dam and Prologue saves. The timings are from one checkpoint on this machine.

## Development and implementation

1. Reproduce the load in a copy of the save profile. Set `GOW3_FILE_TRACE=.psarc` and compare the time spent inside file reads with the elapsed loading interval. The long gaps between fast reads pointed to package scheduling.
2. Inspect the CUSA00552 1.11 package login routine around image offset `0xA55800` in the prepared `eboot.elf`. It advances the callback index by one, compares it with the entry count at `0xA558B2`, and returns to the scheduler when work remains. Separate update passes were required for callback entries that could run consecutively.
3. Follow the loading-screen object reference at `0x3E31` and observe its state at `0x1519A70` while loading and after regaining control. States 1 and 2 are the active loading states used to gate batching.
4. In `tools/probe_tlou.py`, register `package-login-batch` with the existing `image_patches()` pipeline. The patch checks the original instructions and zero-filled stub space before emitting two writes in the `G3PATCH2` file. The runtime applies the writes to the loaded image. The on-disk executable and game archives are untouched.
5. The stub at `0x91` preserves the original comparison. With callbacks pending in state 1 or 2, it branches to `0xA5584A` to reload the callback table and process the next entry. Completion still runs the original listener notification. In other states it returns control to the scheduler after the original callback. An index greater than the count also returns to the scheduler. The branch targets use relative displacements so they follow the relocated image.

## Install on Windows

1. Close the game. Back up `tools/probe_tlou.py` from the port folder.
2. Extract the ZIP. In PowerShell, change to the port folder containing `tools\probe_tlou.py`. Git for Windows must be available on PATH. Replace the example path with the extracted patch's full path.

   ```powershell
   $patch = 'C:\path\to\improved-loading-times.patch'
   git apply --check "$patch"
   git apply "$patch"
   ```

3. Use the normal launcher with the CUSA00552 1.11 game files. No build is required for an installed port. Continue a save or use **Load Game**. The launcher log should report `Patches: package-login-batch on` on a matching executable.
4. If the patch check fails, see whether your script already defines `package_login_batch_patch`. If present, the improvement is already installed. For a customized version, merge the function and its registration from the patch into the matching sections of your script. Preserve your active settings and review the resulting diff before launching. You can also apply it to a clean checkout of the stated base.
5. For a temporary comparison, launch with `TLOU_FAST_LOADING=0` in the game's environment. To uninstall permanently, close the game and restore your backup.

## Reproduce a benchmark on a source checkout

Apply the patch as above, then build the port as usual if the checkout has no built runtime. Use the same save, renderer settings, and shader cache for both runs. Start a fresh process with a copied save profile for each run. Run the baseline with `TLOU_FAST_LOADING=0`, then unset it for the patched run. Enable `GOW3_FILE_TRACE=.psarc` for both. Record the same archive and `Load vTex` markers from each boot log. Confirm that the loaded scene renders and accepts character input, including when loading a different chapter through the pause menu.

## Instalação em português

Feche o jogo, faça uma cópia de `tools\probe_tlou.py` e extraia o ZIP. Abra o PowerShell na pasta do port e rode os dois comandos da seção **Install on Windows** com o caminho real do arquivo `.patch`. Se a verificação passar, abra o launcher e carregue o save. A melhoria funciona com **CUSA00552 1.11** e dispensa recompilar a instalação. Se a função `package_login_batch_patch` já estiver no script, a melhoria já está instalada. Para desinstalar, feche o jogo e restaure a cópia do arquivo.
